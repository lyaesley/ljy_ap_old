

var Calendar;
var CurYear;

DatePicker = function(id, container, year, month, day, x, y) {
	if (arguments.length > 0){
		this.initialize(id, container, year, month, day, x, y);
	}
}
DatePicker.prototype.initialize = function(id, container, year, month, day, x, y) {
	
	this.id = id;
	this.container = document.getElementById(container);

	if(this.container==null){
		this.container = document.createElement("DIV");
		this.container.id = container;
		var divs = document.getElementsByTagName("DIV")
		this.container.style.zIndex = "1000"; //divs.length + 1;
		document.body.appendChild(this.container);
	}
	this.container.innerHTML = "";
	this.container.style.display = "block";

	this.container.style.width = "177px";
	this.container.style.padding = "2px";
	this.container.style.backgroundColor = "#fff";
	
	if(x){	
		this.container.style.position = "absolute";
		this.container.style.left = parseInt(x,10)+"px";	
		this.container.style.top = parseInt(y,10)+"px";	
		this.container.style.border = "1px solid #9C9C9C";
		this.container.style.backgroundColor = "#ffffff";	
	}	
	this.year = year;
	this.month = month;
	this.day = day;
	this.header = null;
	this.grid = null;
	this.gridBackGroundColor = new Array();
	CurYear = year;
	
	var navigator = document.createElement("DIV");
	navigator.id = "dateNavi";
	navigator.style.textAlign = "center";
	navigator.style.padding = "2px 0 0 0";
	navigator.style.width = "177px";
	navigator.style.height = "24px";
	navigator.style.backgroundColor = "#eceef0";
	this.container.appendChild(navigator);
	this.navigator = navigator;
	
	var g = document.createElement("DIV");
	g.id = "gridMiniContainer";
	g.style.backgroundColor = "#eceef0";
	g.style.width = "177px"; //100%
	g.align = "center";
	g.style.padding = "2px 0";
	this.container.appendChild(g);	
	this.gridContainer = g;
	
	this.DatesForMonth = new Array();
	
	// for makeTD
	this.idx = 0;
		
	this.Locale = {
		// Locale definition
		MONTHS                : ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
		MONTHS_NUMERIC   : [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
		WEEKDAYS             : ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"]
	};
	// calendar i??i?¡¾
	this.buildCalendar();
}
DatePicker.prototype.clearCalendar = function(){
	this.idx = 0;
	this.DatesForMonth = new Array();
	this.gridBackGroundColor = new Array();			
	$('dateNavi').innerHTML = "";
	$('gridMiniContainer').innerHTML = "";
}
DatePicker.prototype.rebuildCalendar = function(){
	this.clearCalendar();
	this.buildCalendar();
}
DatePicker.prototype.buildCalendar = function(){

	var numrows = getWeekCountOfMonth(this.year, this.month);

	var headerLabels = this.Locale.WEEKDAYS;
	this.DatesForMonth  = getMonthArray(this.year, this.month);

	// build grid
	this.setNavigator();      

	var h = this.makeHeader(headerLabels, 7);

	this.header = h;

	
	var g = this.makeCalendar(numrows, 7);	
	this.setGridBackGroundColor(g);
}
DatePicker.prototype.makeHeader = function(labels, cols){
	var div = document.createElement("DIV");	
	var t = document.createElement("TABLE");
	//t.style.width = 100%
	var tb = document.createElement("TBODY");
	var tr = document.createElement("TR");	
	t.cellPadding = "0";
	t.cellSpacing = "0";
	
	div.style.fontSize = "11px";
	div.style.margin = "0 2px";
	div.style.width = "171px"; //100%
	div.style.borderLeft = "1px solid #d6d3de";
	div.style.borderRight = "1px solid #d6d3de";
	div.style.borderTop = "1px solid #d6d3de";
	div.style.filter = "progid:DXImageTransform.Microsoft.Gradient(gradientType=0,startColorStr=#FFFFFF,endColorStr=#F2F4F5);"; 
	
	for(var i=0; i<cols; i++){
		var td = this.makeHeaderTD(-1, i, labels[i]);
		td.style.filter = "progid:DXImageTransform.Microsoft.Gradient(gradientType=0,startColorStr=#FFFFFF,endColorStr=#F2F4F5);"; 
		tr.appendChild(td);
	}
	tb.appendChild(tr);
	t.appendChild(tb);	
	div.appendChild(t);	

	this.gridContainer.appendChild(div);
	
	return t;
}
DatePicker.prototype.makeHeaderTD = function(rows, cols, label){
	var td = document.createElement("TD");	
	var weekday = document.createTextNode(label);
		
	td.rows = rows;
	td.cols = cols;
	
	td.style.fontFamily = "arial,Tahoma,verdana,e¥ì¢¥e|¨ù,e??i?";
	td.style.fontSize = "11px";
	td.style.fontWeight = "bold";
	td.style.width = "16px";	//100%
	td.style.height = "16px";
	td.style.padding = "2px";
	td.style.textAlign = "center";
	
	if(cols==0) td.style.color = "red";	
	if(cols==6) td.style.color = "#6666FF";
	td.appendChild(weekday);
	return td;
}	
DatePicker.prototype.makeCalendar = function (rows, cols){
	var div = document.createElement("DIV");
	var t = document.createElement("TABLE");	
	var tb = document.createElement("TBODY");

	div.style.padding = "0";
	div.style.width = "173px";	//100%
		
	t.numrows = rows;
	t.numcols = cols;	
	t.cellPadding = "0";
	t.cellSpacing = "1";
	//t.style.width = 100%
	t.style.backgroundColor = "#D0D3D8";	
	
	this.gridBackGroundColor = new Array();
	for(var i=0; i<rows; i++){
		this.gridBackGroundColor[i] = new Array(cols);
	}
	for(var i=0; i<rows; i++){
		var tr = document.createElement("TR");				
		for(var j=0; j<cols; j++){			
			var td = this.makeTD(i, j);
			tr.appendChild(td);
		}
		tb.appendChild(tr);
	}
	t.appendChild(tb);	
	div.appendChild(t);	
	this.gridContainer.appendChild(div);
	
	return t;
}
DatePicker.prototype.makeTD = function(rows, cols){
	var td = document.createElement("TD");	
	var d = new Date(this.DatesForMonth[this.idx][0], parseInt(this.DatesForMonth[this.idx][1],10)-1, parseInt(this.DatesForMonth[this.idx][2],10));
	var sYear = d.getFullYear();
	var sMonth = d.getMonth()+1;
	var sDay = d.getDate();		
	var weekday = d.getDay();	
	
	td.rows = rows;
	td.cols = cols;
	
	td.style.fontFamily = "e¥ì¢¥e|¨ù,e??i?,arial,Tahoma,verdana";
	td.style.fontSize = "11px";
	td.style.color = "#333333";
	td.style.textAlign = "center";
	td.style.backgroundColor = "#ffffff";
	td.style.height = "16px";
	td.style.width = "16px";	//100%
	td.style.padding = "2px";
	td.style.cursor = "hand";	
	
	td.id = "S" + this.DatesForMonth[this.idx][0] + this.DatesForMonth[this.idx][1] + this.DatesForMonth[this.idx][2];
	td.lunar = convertLunarDate(parseInt(this.DatesForMonth[this.idx][0],10), parseInt(this.DatesForMonth[this.idx][1],10), parseInt(this.DatesForMonth[this.idx][2],10), 2);	
	
	if(this.month==sMonth){
		var today  = new Date();
		var year = today.getFullYear();
		var month = today.getMonth()+1;
		var day = today.getDate();
	
		if(year==sYear && month==sMonth && day==sDay){
			td.style.backgroundColor = "#FBE0B1"; 
			td.onmouseover = function(){ this.style.backgroundColor = "#D8ECF6"; };
			td.onmouseout = function(){ this.style.backgroundColor = "#ffffff"; };
		}else{
			td.onmouseover = function(){ this.style.backgroundColor = "#D8ECF6"; };
			td.onmouseout = function(){ this.style.backgroundColor = "#ffffff"; };
		}
		if(weekday==0){
			td.style.color = "red";	
		}else if(weekday==6){
			td.style.color = "#6666FF";
		}	
	}else{
		td.style.backgroundColor = "#F7F7F7"; 
		td.onmouseover = function(){ this.style.backgroundColor = "#D8ECF6"; };
		td.onmouseout = function(){ this.style.backgroundColor = "#ffffff"; };
		td.style.color = "#CCCCCC";	
	}
	this.idx++;	
	
	var daylabel = document.createTextNode(parseInt(td.id.substr(7, 2),10));
	td.appendChild(daylabel);
	td.onclick = this.clickHandler;
	return td;
}
DatePicker.prototype.setGridBackGroundColor = function(grid){
	var rows =  grid.numrows;
	var cols = grid.numcols;
	for(var i=0; i<rows;i++){
		for(var j=0; j<cols; j++){
			var td = this.getTD(i, j, grid);
			//this.gridBackGroundColor[i][j] = td.currentStyle.backgroundColor;
			this.gridBackGroundColor[i][j] = td.style.backgroundColor;
		}	
	}
}
DatePicker.prototype.getTD = function (row, col, grid){
	var tr = this.getTR(row, grid);
	if(tr==null){
		return null;
	}else{
		return tr.childNodes[col];
	}
	return null;
}
DatePicker.prototype.getTR = function (row, grid){
	if(row==-1){
		return grid.firstChild.childNodes[0];
	}else{
		return grid.firstChild.childNodes[row];
	}
}
DatePicker.prototype.setNavigator = function(){
	var _self = this;
	var id = this.id;
	var navigator = this.navigator;
	var t = document.createElement("TABLE");		
	var tb = document.createElement("TBODY");
	var tr = document.createElement("TR");
	var tdLeft = document.createElement("TD");
	var tdCenter = document.createElement("TD");
	var ComboYear = document.createElement("SELECT");
	ComboYear.id = "test_year";
	var ComboYearOption;
	var ComboMonth = document.createElement("SELECT");
	var ComboMonthOption;
	var tdRight = document.createElement("TD");
	var tdClose = document.createElement("TD");
	
	tdLeft.style.width = "16px";
	tdLeft.style.padding = "0px";
	tdLeft.style.textAlign = "left";
	tdLeft.style.backgroundColor = "#eceef0";
	tdLeft.innerHTML = "<img src='/images/b01_pre.gif' width='14' height='14' align='absmidle' border='0'>";
	tdLeft.onclick = function(){
		_self.previousMonth();
	}
	
	tr.appendChild(tdLeft);

	for (var i = CurYear - 10; i <= CurYear + 10; i++) {
		
		ComboYearOption = document.createElement("OPTION");
		ComboYear.appendChild(ComboYearOption);
		ComboYearOption.value = i;
		ComboYearOption.text = i;

		if (i == this.year) {
			ComboYearOption.selected = true;
		}
	}

	for (var i = 1; i <= 12; i++) {
		ComboMonthOption = document.createElement("OPTION");
		ComboMonth.appendChild(ComboMonthOption);
		ComboMonthOption.value = i;
		ComboMonthOption.text = i;

		if (i == this.month) {
			ComboMonthOption.selected = true;
		}
	}

	tdCenter.style.backgroundColor = "#eceef0";
	ComboYear.style.marginRight = '4px';
	ComboYear.onchange = function() { 

		_self.year = parseInt(this.value);
		_self.rebuildCalendar();
	}
	tdCenter.appendChild(ComboYear);

	ComboMonth.onchange = function() { 

		_self.month = parseInt(this.value);
		_self.rebuildCalendar();
	}
	tdCenter.appendChild(ComboMonth);
	tr.appendChild(tdCenter);
		
	/*
	tdCenter.style.color = "#333333";
	tdCenter.style.padding = "0px 0px 0px 0px";
	tdCenter.style.textAlign = "center";
	tdCenter.style.backgroundColor = "#eceef0";
	tdCenter.innerHTML = this.Locale.MONTHS[parseInt(this.month,10)-1]+" "+parseInt(this.year,10);
	tdCenter.style.fontFamily = "arial,verdana,Tahoma,e¥ì¢¥e|¨ù,e??i?"
	tdCenter.style.fontSize = "12px";
	tdCenter.style.fontWeight = "bold";
	tr.appendChild(tdCenter);
	*/
	
	tdRight.style.width = "16px";
	tdRight.style.padding = "0px";
	tdRight.style.backgroundColor = "#eceef0";
	tdRight.style.textAlign = "left";
	tdRight.innerHTML = "<img src='/images/b01_next.gif' width='14' height='14' align='absmidle' border='0'>";
	tdRight.onclick = function(){
		_self.nextMonth();
	}
	tr.appendChild(tdRight);
	
	tdClose.style.width = "16px";
	tdClose.style.padding = "0px";
	tdClose.style.backgroundColor = "#eceef0";
	tdClose.style.textAlign = "right";
	tdClose.style.cursor = "hand";
	tdClose.innerHTML = "<img src='/images/btnClose.gif' width='14' height='14' align='absmidle' border='0'>";
	tdClose.onclick = function(){
		document.getElementById("CALCT").style.display = "none";
	}
	tr.appendChild(tdClose);
		
	tb.appendChild(tr);	
	t.appendChild(tb);	
	navigator.appendChild(t);
}

DatePicker.prototype.previousMonth = function(){
	var day = this.day;
	var month = this.month-1;
	var year = this.year;
	var cd = 	getDaysOfCurrMonth(year, month);
	if(month<1){
		month = 12;
		year--;
	}	
	if(day>cd) day = cd;

	this.year = year;
	this.month = month;
	this.day = day;	
	this.rebuildCalendar();
}
DatePicker.prototype.nextMonth = function(){
	var day = this.day;
	var month = this.month+1;
	var year = this.year;
	var cd = 	getDaysOfCurrMonth(year, month);
	
	if(month>12){
		month = 1;
		year++;
	}
	if(day>cd) day = cd;
	
	this.year = year;
	this.month = month;
	this.day = day;
	this.rebuildCalendar();
}
DatePicker.prototype.getID = function(){
	var id = this.id;
	return id.substr(1, 8);
}
DatePicker.prototype.clickHandler = function(){}

var checkStartDate = 0;
var checkEndDate = 0;
var isStartDateCheck = false;
var dateCheckFlag = true;
var isTodayDateCheck = false;
var checkTodayDate = 0;
var isDateDiffCheck = false;
var checkDateDiff = 30;
var checkDate = "";

DatePicker.prototype.clickHandler =  function(){
	var id = this.id;
	year  = id.substr(1, 4);
	month = id.substr(5, 2);
	day   = id.substr(7, 2);
	
	var selectedDate = parseFloat(year + month + day)

	if (dateCheckFlag)  {
		

		if (isStartDateCheck && checkEndDate < selectedDate) {
			alert("시작일자가 종료일자보다 큽니다.");
			document.getElementById("CALCT").style.display = "none";
			return;
		}

		if (!isStartDateCheck && checkStartDate > selectedDate) {
			alert("종료일자가 시작일자보다 작습니다.");
			document.getElementById("CALCT").style.display = "none";
			return;
		}
	}	
	
	//금일 일자 기준 체크
	if (isTodayDateCheck){
		if (checkTodayDate < selectedDate){
			alert("날짜를 잘못 선택하셨습니다.");
			document.getElementById("CALCT").style.display = "none";
			return;
		}
	}
	
	//날수 체크
	var dFrom = null;
	var dTo = null;
	if (isDateDiffCheck) {
		
		if (isStartDateCheck){
			dFrom = new Date(parseInt(year, 10), parseInt(month, 10)-1, parseInt(day, 10));
			dTo = (checkEndDate) ? new Date(parseInt(checkEndDate.toString().substr(0, 4), 10), parseInt(checkEndDate.toString().substr(4, 2), 10)-1, parseInt(checkEndDate.toString().substr(6, 2), 10)) : 0;
		}else{
			dTo = new Date(parseInt(year, 10), parseInt(month, 10)-1, parseInt(day, 10));
			dFrom = (checkStartDate) ? new Date(parseInt(checkStartDate.toString().substr(0, 4), 10), parseInt(checkStartDate.toString().substr(4, 2), 10)-1, parseInt(checkStartDate.toString().substr(6, 2), 10)) : 0;
			//alert(dFrom);
		}
		
		if (dTo * dFrom > 0){
			if (Math.ceil((dTo - dFrom) / 1000 / 24 / 60 / 60) > checkDateDiff){
				alert("조회 기간은 " + checkDateDiff + "일을 초과할 수 없습니다.");
				return;
			}
		}
	}

	$(objCal.id).value = year + "-" + month + "-" + day;
	//$(objCal.id).value = year+month+day;
	objCal.container.style.display = "none";
}
function callCalPop(ctl1, ctl2, todayCheckYn, endId) {

	isStartDateCheck = false;
	dateCheckFlag = false;
	
	isTodayDateCheck = (todayCheckYn == '' || todayCheckYn == null) ? false : eval(todayCheckYn);
	today = new Date();
	var toYear = today.getYear().toString();
	var toMonth = (((today.getMonth() + 1) < 10) ? "0" + (today.getMonth()+1).toString() : (today.getMonth()+1).toString());
	var toDate = ((today.getDate() < 10) ? "0" + today.getDate().toString() : today.getDate().toString());
	checkTodayDate = parseFloat(toYear + toMonth + toDate);

	var posXY = Position.cumulativeOffset($(ctl2));
	var Now = new Object();
	if(!$(ctl1).value){
		date = new Date();
		Now.year = date.getYear();
		Now.month = date.getMonth()+1;
		Now.date = date.getDate();
	}else{
		aryVal = $(ctl1).value.split("-");
		Now.year = parseInt(aryVal[0]);
		Now.month = parseInt(aryVal[1],10);
		Now.date = parseInt(aryVal[2],10);
	}
	objCal = new DatePicker(ctl1, "CALCT", Now.year, Now.month, Now.date, posXY[0], (posXY[1]+$(ctl2).offsetHeight+2));
}

function callCalPop_UpPos(ctl1, ctl2, todayCheckYn, endId) {

	isStartDateCheck = false;
	dateCheckFlag = false;
	
	isTodayDateCheck = (todayCheckYn == '' || todayCheckYn == null) ? false : eval(todayCheckYn);
	today = new Date();
	var toYear = today.getYear().toString();
	var toMonth = (((today.getMonth() + 1) < 10) ? "0" + (today.getMonth()+1).toString() : (today.getMonth()+1).toString());
	var toDate = ((today.getDate() < 10) ? "0" + today.getDate().toString() : today.getDate().toString());
	checkTodayDate = parseFloat(toYear + toMonth + toDate);

	var posXY = Position.cumulativeOffset($(ctl2));
	var Now = new Object();
	if(!$(ctl1).value){
		date = new Date();
		Now.year = date.getYear();
		Now.month = date.getMonth()+1;
		Now.date = date.getDate();
	}else{
		aryVal = $(ctl1).value.split("-");
		Now.year = parseInt(aryVal[0]);
		Now.month = parseInt(aryVal[1],10);
		Now.date = parseInt(aryVal[2],10);
	}
	objCal = new DatePicker(ctl1, "CALCT", Now.year, Now.month, Now.date, posXY[0], (posXY[1]-177));
}

function callCalPop4Statistics(ctl1, ctl2, startId, endId, isDateDiff, dateDiffCnt) {

	isStartDateCheck = false;
	isDateDiffCheck = eval(isDateDiff);
	checkDateDiff = (dateDiffCnt == null || dateDiffCnt == "" || dateDiffCnt <= 0) ? 30 : dateDiffCnt;
	
	if (startId != "" || endId != "") {
		if (endId == "") {
			if ($(startId).value == "" || $(startId) == null) {
				alert("시작일자를 먼저 선택해주세요.");
				return;
			}
		}
		if (startId == "") {
			isStartDateCheck = true;
		}
		if (startId != "") {
			checkStartDate = parseFloat($(startId).value.split("-").join(""));
		} 
		if (endId != "") {
			checkEndDate = parseFloat($(endId).value.split("-").join(""));
		}
	} else {
		dateCheckFlag = false;
	}

	var posXY = Position.cumulativeOffset($(ctl2));
	var Now = new Object();
	if(!$(ctl1).value){
		date = new Date();
		Now.year = date.getYear();
		Now.month = date.getMonth()+1;
		Now.date = date.getDate();
	}else{
		aryVal = $(ctl1).value.split("-");
		Now.year = parseInt(aryVal[0]);
		Now.month = parseInt(aryVal[1],10);
		Now.date = parseInt(aryVal[2],10);
	}
	
	objCal = new DatePicker(ctl1, "CALCT", Now.year, Now.month, Now.date, posXY[0],  (posXY[1]+$(ctl2).offsetHeight+2));
}

/*DatePicker.prototype.clickHandler =  function(){
	var id = this.id;
	year  = id.substr(1, 4);
	month = id.substr(5, 2);
	day   = id.substr(7, 2);
	$(objCal.id).value = year + "-" + month + "-" + day;
	//$(objCal.id).value = year+month+day;
	objCal.container.style.display = "none";
}

function callCalPop(ctl1, ctl2) {

	var posXY = Position.cumulativeOffset($(ctl2));
	var Now = new Object();
	if(!$(ctl1).value){
		date = new Date();
		Now.year = date.getYear();
		Now.month = date.getMonth()+1;
		Now.date = date.getDate();
	}else{
		aryVal = $(ctl1).value.split("-");
		Now.year = parseInt(aryVal[0]);
		Now.month = parseInt(aryVal[1],10);
		Now.date = parseInt(aryVal[2],10);
	}
	objCal = new DatePicker(ctl1, "CALCT", Now.year, Now.month, Now.date, posXY[0], (posXY[1]+$(ctl2).offsetHeight+2));
}*/




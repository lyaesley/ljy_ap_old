var target;
var stime;
var calendar;

document.writeln('<div id="minical" onmouseover="Calendar_Over()" onmouseout="Calendar_Out()" style="background: buttonface; margin:2; border: 1 solid buttonshadow; width:160; display:none; position:absolute; z-index:1000">');
document.writeln('<iframe id="Cal_iFrame" width=160 height=130 src="/common/cal/cal.html" scrolling=no frameborder=no border=1 bordercolor=red></iframe>');
document.writeln('</div>');

function Calendar_Over() {
	window.clearTimeout(stime);
}

function Calendar_Out() {
	stime=window.setTimeout("calendar.style.display='none';", 200);
}

function Calendar_Click(e) {
	cal_Day = e.title;
	if (cal_Day.length > 6) {
		target.value = cal_Day
	}	
	calendar.style.display='none';
}

function Calendar_D(obj) {
	var now = obj.value.split("-");
	target = obj;															

	var top = document.body.clientTop + GetObjectTop(obj);
	var left = document.body.clientLeft + GetObjectLeft(obj);

	calendar = document.all.minical;
	calendar.style.pixelTop = top + obj.offsetHeight;
	calendar.style.pixelLeft = left;
	calendar.style.display = '';
	
	if (now.length == 3) {											
		Cal_iFrame.Show_cal(now[0],now[1],now[2]);					
	} else {
		now = new Date();
		 Cal_iFrame.Show_cal(now.getFullYear(), now.getMonth()+1, now.getDate());
	}
}

function Calendar_M(obj) {
	var now = obj.value.split("-");
	target = obj;															

	var top = document.body.clientTop + GetObjectTop(obj);
	var left = document.body.clientLeft + GetObjectLeft(obj);

	calendar = document.all.minical;
	calendar.style.pixelTop = top + obj.offsetHeight;
	calendar.style.pixelLeft = left;
	calendar.style.display = '';
	
	if (now.length == 2) {
		Cal_iFrame.Show_cal_M(now[0],now[1]);					
	} else {
		now = new Date();
		Cal_iFrame.Show_cal_M(now.getFullYear(), now.getMonth()+1);
	}
}

/**
	HTML 개체용 유틸리티 함수
**/
function GetObjectTop(obj)
{
	if (obj.offsetParent == document.body)
		return obj.offsetTop;
	else
		return obj.offsetTop + GetObjectTop(obj.offsetParent);
}

function GetObjectLeft(obj)
{
	if (obj.offsetParent == document.body)
		return obj.offsetLeft;
	else
		return obj.offsetLeft + GetObjectLeft(obj.offsetParent);
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * JS 페이지 공통 환경 변수.
 * 컨텍스트패스와 이미지 서버 url을 지정해서 담습니다.
 * 필요한 변수들 정의 하시면 됩니다.
 * 
	$(document).ready(function(){
		setContextPath("${pageContext.request.contextPath }");
	});
 */

/*
front 검색 기간(1주일, 15일, 1달, 3달) 구하기 
*/
function setOrderSearchDate(term, start, end) {
	
	// 오늘...
	if(term == "today") {
		start.value = shiftDate(getCurrentTime(), 0, 0, 0, "-");
		end.value = getCurrentDate("-");
	}
	// 1주일 이면...
	else if(term == "7day") {
		start.value = shiftDate(getCurrentTime(), 0, 0, -6, "-");
		end.value = getCurrentDate("-");
	}
	
	// 30일 이면...
	else if(term == "30day") {
		start.value = shiftDate(getCurrentTime(), 0, 0, -29, "-");
		end.value = getCurrentDate("-");
	}
	
	// 60일 이면...
	else if(term == "60day") {
		start.value = shiftDate(getCurrentTime(), 0, 0, -59, "-");
		end.value = getCurrentDate("-");
	}
	
	// 90일 이면...
	else if(term == "90day") {
		start.value = shiftDate(getCurrentTime(), 0, 0, -89, "-");
		end.value = getCurrentDate("-");
	}
	
	// 180일 이면...
	else if(term == "180day") {
		start.value = shiftDate(getCurrentTime(), 0, 0, -179, "-");
		end.value = getCurrentDate("-");
	}

}

function setOrderSearchDate(term, start) {
	
	// 오늘...
	if(term == "today") {
		start.value = shiftDate(getCurrentTime(), 0, 0, 0, "-");
	}
}	

function shiftDate(time,y,m,d, dele) { //moveTime(time,y,m,d)
    var date = toDateObject(time);

    date.setFullYear(date.getFullYear() + y); //y년을 더함
    date.setMonth(date.getMonth() + m);       //m월을 더함
    date.setDate(date.getDate() + d);         //d일을 더함

    return toDateString(date, dele);
}


/**
 * Time 스트링을 자바스크립트 Date 객체로 변환
 * parameter time: Time 형식의 String
 */
function toDateObject(time) { //parseTime(time)
    var year  = time.substr(0,4);
    var month = time.substr(4,2) - 1; // 1월=0,12월=11
    var day   = time.substr(6,2);

    return new Date(year,month,day);
}

/**
 * 자바스크립트 Date 객체를 Time 스트링으로 변환
 * parameter date: JavaScript Date Object
 */
function toDateString(date, dele) { //formatTime(date)
    var year  = date.getFullYear();
    var month = date.getMonth() + 1; // 1월=0,12월=11이므로 1 더함
    var day   = date.getDate();

    if (("" + month).length == 1) { month = "0" + month; }
    if (("" + day).length   == 1) { day   = "0" + day;   }

    return ("" + year + dele + month + dele + day)
}

/**
 * 현재 시각을 Time 형식으로 리턴

 */
function getCurrentTime() {
    return toTimeString(new Date());
}

/**
 * 자바스크립트 Date 객체를 Time 스트링으로 변환
 * parameter date: JavaScript Date Object
 */
function toTimeString(date) { //formatTime(date)
    var year  = date.getFullYear();
    var month = date.getMonth() + 1; // 1월=0,12월=11이므로 1 더함
    var day   = date.getDate();
   /* var hour  = date.getHours();
    var min   = date.getMinutes();*/

    if (("" + month).length == 1) { month = "0" + month; }
    if (("" + day).length   == 1) { day   = "0" + day;   }
   /* if (("" + hour).length  == 1) { hour  = "0" + hour;  }
    if (("" + min).length   == 1) { min   = "0" + min;   }*/

    return ("" + year + month + day );
}


/**
 * 현재 시각을 Date 형식으로 리턴

 */
function getCurrentDate(dele) {
    return toFormatString(toTimeString(new Date()), "-");
}

/**
 * 자바스크립트 Date 객체를 Time 스트링으로 변환
 * parameter date: JavaScript Date Object
 */
function toTimeString(date) { //formatTime(date)
    var year  = date.getFullYear();
    var month = date.getMonth() + 1; // 1월=0,12월=11이므로 1 더함
    var day   = date.getDate();
    var hour  = date.getHours();
    var min   = date.getMinutes();

    if (("" + month).length == 1) { month = "0" + month; }
    if (("" + day).length   == 1) { day   = "0" + day;   }
    if (("" + hour).length  == 1) { hour  = "0" + hour;  }
    if (("" + min).length   == 1) { min   = "0" + min;   }

    return ("" + year + month + day + hour + min)
}

/**
 * Time 스트링을 자바스크립트 Date 객체로 변환
 * parameter time: Time 형식의 String
 */
function toFormatString(time, dele) { //parseTime(time)
    var year  = time.substr(0,4);
    var month = time.substr(4,2); // 1월=0,12월=11
    var day   = time.substr(6,2);

    return ("" + year + dele + month + dele + day)
}


var userLanguage = navigator.userLanguage; // ko: 대한민국, cn: 중국, en: 미국, ja: 일본
var LARGE_LUNAR, SMALL_LUNAR;

if(userLanguage=="ko"){
	LEAP_MONTH = "윤" ;
}else if(userLanguage=="cn"){
	LEAP_MONTH = "閏";
}else if(userLanguage=="ja"){
	LEAP_MONTH = "閏";
}else{
	LEAP_MONTH = "leap month" ;
}
var MONTH_DAY_CNT = new Array(31,0,31,30,31,30,31,31,30,31,30,31);
var LUNAR_CNT = new Array(  1,2,4,1,1,2,1,2,1,2,2,1,
							2,2,1,2,1,1,2,1,2,1,2,1,
							2,2,2,1,2,1,4,1,2,1,2,1,
							2,2,1,2,1,2,1,2,1,2,1,2,
							1,2,1,2,2,1,2,1,2,1,2,1,
							2,1,2,1,5,2,1,2,2,1,2,1,
							2,1,1,2,1,2,1,2,2,2,1,2,
							1,2,1,1,2,1,2,1,2,2,2,1,
							2,1,2,3,2,1,2,1,2,1,2,2,
							2,1,2,1,1,2,1,1,2,2,1,2,
							2,2,1,2,1,1,2,1,2,1,5,2,
							2,1,2,2,1,1,2,1,2,1,1,2,
							2,1,2,2,1,2,1,2,1,2,1,2,
							1,2,1,2,1,2,5,2,1,2,1,2,
							1,1,2,1,2,2,1,2,2,1,2,1,
							2,1,1,2,1,2,1,2,2,2,1,2,
							1,2,1,1,5,2,1,2,1,2,2,2,
							1,2,1,1,2,1,1,2,2,1,2,2,
							2,1,2,1,1,2,1,1,2,1,2,2,
							2,1,6,1,1,2,1,1,2,1,2,2,
							1,2,2,1,2,1,2,1,2,1,1,2,
							2,1,2,1,2,2,1,2,2,3,1,2,
							1,2,2,1,2,1,2,2,1,2,1,2,
							1,1,2,1,2,1,2,2,1,2,2,1,
							2,1,1,2,4,1,2,2,1,2,2,1,
							2,1,1,2,1,1,2,2,1,2,2,2,
							1,2,1,1,2,1,1,2,1,2,2,2,
							1,2,2,3,2,1,1,2,1,2,2,1,
							2,2,2,1,1,2,1,1,2,1,2,1,
							2,2,2,1,2,1,2,1,1,5,2,1,
							2,2,1,2,2,1,2,1,2,1,1,2,
							1,2,1,2,2,1,2,1,2,2,1,2,
							1,1,2,1,2,4,2,1,2,2,1,2,
							1,1,2,1,2,1,2,1,2,2,2,1,
							2,1,1,2,1,1,2,1,2,2,2,1,
							2,2,1,1,5,1,2,1,2,2,1,2,
							2,2,1,1,2,1,1,2,1,2,1,2,
							2,2,1,2,1,2,1,1,2,1,2,1,
							2,2,4,2,1,2,1,1,2,1,2,1,
							2,1,2,2,1,2,2,1,2,1,1,2,
							1,2,1,2,1,2,5,2,2,1,2,1,
							1,2,1,2,1,2,1,2,2,1,2,2,
							1,1,2,1,1,2,1,2,2,2,1,2,
							2,1,1,2,3,2,1,2,2,1,2,2,
							2,1,1,2,1,1,2,1,2,1,2,2,
							2,1,2,1,2,1,1,2,1,2,1,2,
							2,2,1,5,2,1,1,2,1,2,1,2,
							2,1,2,2,1,2,1,1,2,1,2,1,
							2,1,2,2,1,2,1,2,1,2,1,2,
							1,5,2,1,2,2,1,2,1,2,1,2,
							1,2,1,2,1,2,1,2,2,1,2,2,
							1,1,2,1,1,5,2,2,1,2,2,2,
							1,1,2,1,1,2,1,2,1,2,2,2,
							1,2,1,2,1,1,2,1,2,1,2,2,
							2,1,2,1,5,1,2,1,2,1,2,1,
							2,2,2,1,2,1,1,2,1,2,1,2,
							1,2,2,1,2,1,2,1,2,1,2,1,
							2,1,5,2,2,1,2,1,2,1,2,1,
							2,1,2,1,2,1,2,2,1,2,1,2,
							1,2,1,1,2,1,2,5,2,2,1,2,
							1,2,1,1,2,1,2,1,2,2,2,1,
							2,1,2,1,1,2,1,2,1,2,2,2,
							1,2,1,2,3,2,1,1,2,2,1,2,
							2,2,1,2,1,1,2,1,1,2,2,1,
							2,2,1,2,2,1,1,2,1,2,1,2,
							1,2,2,4,1,2,1,2,1,2,1,2,
							1,2,1,2,1,2,2,1,2,1,2,1,
							2,1,1,2,2,1,2,1,2,2,1,2,
							1,5,1,2,1,2,1,2,2,2,1,2,
							1,2,1,1,2,1,2,1,2,2,2,1,
							2,1,2,1,1,5,1,2,2,1,2,2,
							2,1,2,1,1,2,1,1,2,2,1,2,
							2,2,1,2,1,1,2,1,1,2,1,2,
							2,2,1,2,5,1,2,1,2,1,1,2,
							2,1,2,2,1,2,1,2,1,2,1,2,
							1,2,1,2,1,2,2,1,2,1,2,1,
							2,3,2,1,2,2,1,2,2,1,2,1,
							2,1,1,2,1,2,1,2,2,2,1,2,
							1,2,1,1,2,1,5,2,2,1,2,2,
							1,2,1,1,2,1,1,2,2,1,2,2,
							2,1,2,1,1,2,1,1,2,1,2,2,
							2,1,2,2,3,2,1,1,2,1,2,2,
							1,2,2,1,2,1,2,1,2,1,1,2,
							2,1,2,1,2,2,1,2,1,2,1,1,
							2,1,2,5,2,1,2,2,1,2,1,2,
							1,1,2,1,2,1,2,2,1,2,2,1,
							2,1,1,2,1,2,1,2,2,1,2,2,
							1,5,1,2,1,1,2,2,1,2,2,2,
							1,2,1,1,2,1,1,2,1,2,2,2,
							1,2,2,1,1,5,1,2,1,2,2,1,
							2,2,2,1,1,2,1,1,2,1,2,1,
							2,2,2,1,2,1,2,1,1,2,1,2,
							1,2,2,1,6,1,2,1,2,1,1,2,
							1,2,1,2,2,1,2,2,1,2,1,2,
							1,1,2,1,2,1,2,2,1,2,2,1,
							2,1,4,1,2,1,2,1,2,2,2,1,
							2,1,1,2,1,1,2,1,2,2,2,1,
							2,2,1,1,2,1,4,1,2,2,1,2,
							2,2,1,1,2,1,1,2,1,2,1,2,
							2,2,1,2,1,2,1,1,2,1,2,1,
							2,2,1,2,2,4,1,1,2,1,2,1,
							2,1,2,2,1,2,2,1,2,1,1,2,
							1,2,1,2,1,2,2,1,2,2,1,2,
							1,1,2,4,1,2,1,2,2,1,2,2,
							1,1,2,1,1,2,1,2,2,2,1,2,
							2,1,1,2,1,1,2,1,2,2,1,2,
							2,5,1,2,1,1,2,1,2,1,2,2,
							2,1,2,1,2,1,1,2,1,2,1,2,
							2,2,1,2,1,2,3,2,1,2,1,2,
							2,1,2,2,1,2,1,1,2,1,2,1,
							2,1,2,2,1,2,1,2,1,2,1,2,
							1,2,1,2,4,2,1,2,1,2,1,2,
							1,2,1,1,2,2,1,2,2,1,2,2,
							1,1,2,1,1,2,1,2,2,1,2,2,
							2,1,4,1,1,2,1,2,1,2,2,2,
							1,2,1,2,1,1,2,1,2,1,2,2,
							2,1,2,1,2,1,1,5,2,1,2,2,
							1,2,2,1,2,1,1,2,1,2,1,2,
							1,2,2,1,2,1,2,1,2,1,2,1,
							2,1,2,1,2,5,2,1,2,1,2,1,
							2,1,2,1,2,1,2,2,1,2,1,2,
							1,2,1,1,2,1,2,2,1,2,2,1,
							2,1,2,3,2,1,2,1,2,2,2,1,
							2,1,2,1,1,2,1,2,1,2,2,2,
							1,2,1,2,1,1,2,1,1,2,2,1,
							2,2,5,2,1,1,2,1,1,2,2,1,
							2,2,1,2,2,1,1,2,1,2,1,2,
							1,2,2,1,2,1,5,2,1,2,1,2,
							1,2,1,2,1,2,2,1,2,1,2,1,
							2,1,1,2,2,1,2,1,2,2,1,2,
							1,2,1,1,5,2,1,2,2,2,1,2,
							1,2,1,1,2,1,2,1,2,2,2,1,
							2,1,2,1,1,2,1,1,2,2,2,1,
							2,2,1,5,1,2,1,1,2,2,1,2,
							2,2,1,2,1,1,2,1,1,2,1,2,
							2,2,1,2,1,2,1,5,2,1,1,2,
							2,1,2,2,1,2,1,2,1,2,1,1,
							2,2,1,2,1,2,2,1,2,1,2,1,
							2,1,1,2,1,6,1,2,2,1,2,1,
							2,1,1,2,1,2,1,2,2,1,2,2,
							1,2,1,1,2,1,1,2,2,1,2,2,
							2,1,2,3,2,1,1,2,2,1,2,2,
							2,1,2,1,1,2,1,1,2,1,2,2,
							2,1,2,2,1,1,2,1,1,5,2,2,
							1,2,2,1,2,1,2,1,1,2,1,2,
							1,2,2,1,2,2,1,2,1,2,1,1,
							2,1,2,2,1,5,2,2,1,2,1,2,
							1,1,2,1,2,1,2,2,1,2,2,1,
							2,1,1,2,1,2,1,2,2,1,2,2,
							1,2,1,1,5,1,2,1,2,2,2,2,
							1,2,1,1,2,1,1,2,1,2,2,2,
							1,2,2,1,1,2,1,1,2,1,2,2,
							1,2,5,2,1,2,1,1,2,1,2,1,
							2,2,2,1,2,1,2,1,1,2,1,2,
							1,2,2,1,2,2,1,5,2,1,1,2,
							1,2,1,2,2,1,2,1,2,2,1,2,
							1,1,2,1,2,1,2,2,1,2,2,1,
							2,1,1,2,3,2,2,1,2,2,2,1,
							2,1,1,2,1,1,2,1,2,2,2,1,
							2,2,1,1,2,1,1,2,1,2,2,1,
							2,2,2,3,2,1,1,2,1,2,1,2,
							2,2,1,2,1,2,1,1,2,1,2,1,
							2,2,1,2,2,1,2,1,1,2,1,2,
							1,5,2,2,1,2,1,2,1,2,1,2,
							1,2,1,2,1,2,2,1,2,2,1,1,
							2,1,2,1,2,1,5,2,2,1,2,2,
							1,1,2,1,1,2,1,2,2,2,1,2,
							2,1,1,2,1,1,2,1,2,2,1,2,
							2,2,1,1,5,1,2,1,2,1,2,2,
							2,1,2,1,2,1,1,2,1,2,1,2,
							2,1,2,2,1,2,1,1,2,1,2,1,
							2,1,6,2,1,2,1,1,2,1,2,1,
							2,1,2,2,1,2,1,2,1,2,1,2,
							1,2,1,2,1,2,1,2,5,2,1,2,
							1,2,1,1,2,1,2,2,2,1,2,2,
							1,1,2,1,1,2,1,2,2,1,2,2,
							2,1,1,2,3,2,1,2,1,2,2,2,
							1,2,1,2,1,1,2,1,2,1,2,2,
							2,1,2,1,2,1,1,2,1,2,1,2,
							2,1,2,5,2,1,1,2,1,2,1,2,
							1,2,2,1,2,1,2,1,2,1,2,1,
							2,1,2,1,2,2,1,2,1,2,1,2,
							1,5,2,1,2,1,2,2,1,2,1,2,
							1,2,1,1,2,1,2,2,1,2,2,1,
							2,1,2,1,1,5,2,1,2,2,2,1,
							2,1,2,1,1,2,1,2,1,2,2,2,
							1,2,1,2,1,1,2,1,1,2,2,2,
							1,2,2,1,5,1,2,1,1,2,2,1,
							2,2,1,2,2,1,1,2,1,1,2,2,
							1,2,1,2,2,1,2,1,2,1,2,1,
							2,1,5,2,1,2,2,1,2,1,2,1,
							2,1,1,2,1,2,2,1,2,2,1,2,
							1,2,1,1,2,1,5,2,2,2,1,2,
							1,2,1,1,2,1,2,1,2,2,2,1,
							2,1,2,1,1,2,1,1,2,2,1,2,
							2,2,1,2,1,4,1,1,2,1,2,2,
							2,2,1,2,1,1,2,1,1,2,1,2,
							2,2,1,2,1,2,1,2,1,1,2,1,
							2,2,1,2,5,2,1,2,1,2,1,1,
							2,1,2,2,1,2,2,1,2,1,2,1,
							2,1,1,2,1,2,2,1,2,2,1,2,
							1,5,1,2,1,2,1,2,2,2,1,2,
							1,2,1,1,2,1,1,2,2,1,2,2);


function checkDigit(s){
	var ret = s.toString(10);
    if(ret.length == 1){
        ret = "0" + ret;
    }
	return ret;
}

function getDateArray(dateTxt){
	//dateTxt: "YYYY-MM-DD HH:MM"
	var temp1 = dateTxt.split(" ");
	var temp2 = temp1[0].split("-");
	var temp3 = temp1[1].split(":");
	var dArray = new Array(5);
	
	dArray[0] = temp2[0];
	dArray[1] = temp2[1];
	dArray[2] = temp2[2];
	dArray[3] = temp3[0];
	dArray[4] = temp3[1];
	
	return dArray;
	
}

function convertLunarDate(year, month, day, mode){
	// 처리가능 기간  1841 - 2043년
	var TempDate1;					     // 음력일을 계산하기 위해 양력일과의 차이를 저장할 변수
	var TotalDayCnt;				     // 1840년까지의 날수
	var Temp = 0;
	var Temp1 = 0;
	var Temp2 = 0;
	var lYear;				             // 계산된 음력 년, 월, 일을 저장할 변수
	var lMonth;
	var lDay;
	var lsLunarMonth;				     // 현재월이 윤달임을 표시
	var RetValue;
	var i;
	var j;
	var Flag = true;
	var ArrayTempDate = new Array(250);  // 매년의 음력일수를 저장할 배열 변수(year-1841)

	TotalDayCnt = 672069;                // 672069 = 1840 * 365 + 1840/4 - 1840/100 + 1840/400 + 23
	
	// 윤달여부를 체크
	if(year % 4 != 0){
		MONTH_DAY_CNT[1] = 28;
	}else if(year % 100 != 0 ){
		MONTH_DAY_CNT[1] = 29;
	}else if(year % 400 != 0){
		MONTH_DAY_CNT[1] = 28;
	}else{
		MONTH_DAY_CNT[1] = 29;
	}

	// 1841년부터 작년까지의 날수
	//alert(TempDate2);
	var TempDate2 = (year-1)*365 + (year-1)/4 - (year-1)/100 + (year-1)/400;

	// 전월까지의 날수를 더함
	for(var i=0;i<(month-1);i++){
      		TempDate2 += MONTH_DAY_CNT[i];
	}
	// 현재일까지의 날수를 더함
	TempDate2 = Math.round(TempDate2) + day;

	// 양력현재일과 음력 1840년까지의 날수의 차이
	TempDate1 = TempDate2 - TotalDayCnt + 1;

	// 1841년부터 음력날수를 계산
	for(var i=0;i<(year-1840);i++){
		ArrayTempDate[i] = 0;
		for(j=0;j<12;j++){
			switch(LUNAR_CNT[i*12 + j]){
				case 1:
				    Temp = 29; break;
				case 2:
				    Temp = 30; break;
				case 3:
				    Temp = 58; break;
				case 4:
				    Temp = 59; break;
				case 5:
				    Temp = 59; break;
				case 6:
				    Temp = 60; break;
			}
			ArrayTempDate[i] = ArrayTempDate[i] + Temp;
		}
	}

	// 1840년 이후의 년도 계산
	// 현재까지의 일수에서 위에서 계산된 1841년부터의 매년 음력일수를 빼가면수 년도를 계산
	lYear = 0;
	while(TempDate1 > ArrayTempDate[lYear]){
		TempDate1 = TempDate1 - ArrayTempDate[lYear];
		lYear = lYear + 1;
	}
	lMonth = 0;
	lsLunarMonth = "N";		// 현재월이 윤달임을 표시할 변수 - 기본값 평달
	while(Flag){
        if(LUNAR_CNT[lYear*12 + lMonth] <= 2){
            Temp = LUNAR_CNT[lYear*12 + lMonth] + 28;
            if(TempDate1 > Temp){
                TempDate1 = TempDate1 - Temp;
				lMonth = lMonth + 1;
            }else{
                Flag = false;
            }
        }else{
            switch(LUNAR_CNT[lYear*12 + lMonth]){
                case 3:
					Temp1 = 29; Temp2 = 29; break;
				case 4:
					Temp1 = 29; Temp2 = 30; break;
				case 5:
					Temp1 = 30; Temp2 = 29; break;
				case 6:
					Temp1 = 30; Temp2 = 30; break;
            }
            if(TempDate1 > Temp1){
                TempDate1 = TempDate1 - Temp1;
                if(TempDate1 > Temp2){
                    TempDate1 = TempDate1 - Temp2;
				    lMonth = lMonth + 1;
				}else{
				    lsLunarMonth = "Y";
				}
            }else{
                Flag = false;
            }
        }
    }

	lYear = lYear + 1841;
	lMonth = lMonth + 1;
	lDay = TempDate1;

	if(mode==0){
		RetValue = lYear + "-" + checkDigit(lMonth) + "-" + checkDigit(lDay) + "-" + lsLunarMonth;
	}else if(mode==1){
		if(userLanguage=="ko" || userLanguage=="cn" ||userLanguage=="ja" ){
			if(lsLunarMonth=="Y"){
				RetValue = " (" + LEAP_MONTH + " "+ lMonth + "." + lDay + ")";
			}else{
				RetValue = " (" + lMonth + "." + lDay + ")";
			}
		}else{
			RetValue = "" ;
		}	
	}else{
		RetValue = lYear + "" + checkDigit(lMonth) + "" + checkDigit(lDay)
	}
	return RetValue;
}

function convertSolarDate(year, month, day){
	var sYear;
	var sMonth;
	var sDay;
	var y1;
	var y2 = 0;
	var y3;
	var m1;
	var td;
	var i;
	var j;
	var Flag = true;
	var RetValue = "";

	y1 = year - 1841;
	m1 = month - 1;

	td = 0;
	for(i=0;i<y1;i++){
		for(j=0;j<12;j++){
			switch(LUNAR_CNT[i*12 + j]){
				case 1 : td = td + 29; break;
				case 2 : td = td + 30; break;
				case 3 : td = td + 58; break;
				case 4 : td = td + 59; break;
				case 5 : td = td + 59; break;
				case 6 : td = td + 60; break;
			}
		}
	}

	for(j=0;j<m1;j++){
		switch(LUNAR_CNT[y1*12 + j]){
			case 1 : td = td + 29; break;
			case 2 : td = td + 30; break;
			case 3 : td = td + 58; break;
			case 4 : td = td + 59; break;
			case 5 : td = td + 59; break;
			case 6 : td = td + 60; break;
		}
	}

	td = td + day + 22;

	y1 = 1840;
	while(Flag){
		y1 = y1 + 1;
        if(y1 % 4 != 0){
        	y2 = 365;
        }else if(y1 % 100 != 0){
        	y2 = 366;
        }else if(y1 % 400 != 0){
        	y2 = 365;
        }else{
        	y2 = 366;
        }

		if(td <= y2){
			Flag = false;
		}else{
		    td = td - y2;
		}
	}

	sYear = y1;
	MONTH_DAY_CNT[1] = y2 - 337;
	m1 = 0;
	Flag = true;
	while(Flag){
		m1 = m1 + 1;
		if(td <= MONTH_DAY_CNT[m1-1]){
			Flag = false;
		}else{
		    td = td - MONTH_DAY_CNT[m1-1];
		}
	}

	sMonth = m1;
	sDay = td;
	y3 = sYear;
	td = (y3*365) + (y3/4) - (y3/100) + (y3/400);
	for(i=0;i<sMonth;i++){
		td = td + MONTH_DAY_CNT[i];
	}

	td = td + sDay;

	RetValue = y3 + "-" + checkDigit(sMonth) + "-" + checkDigit(sDay);
    return RetValue;
}

function getWeeknYear(d){
    var ms1d = 86400000, ms3d = 3 * ms1d, ms7d = 7 * ms1d;
    var ret;
    var D3 = Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) + ms3d;
    var wk = Math.floor(D3 / ms7d);
    with (new Date(wk * ms7d)) {
        var yy = getUTCFullYear();
    }
    
    if(d.getDay()==0){
    	ret = 2 + wk - Math.floor((Date.UTC(yy, 0, 4) + ms3d) / ms7d);
    }else{
    	ret = 1 + wk - Math.floor((Date.UTC(yy, 0, 4) + ms3d) / ms7d);
    }
    return d.getFullYear() + "|" + ret;
}

function getWeekOfYear(d){
    var ms1d = 86400000, ms3d = 3 * ms1d, ms7d = 7 * ms1d;
    var ret;
    var D3 = Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) + ms3d;
    var wk = Math.floor(D3 / ms7d);
    with (new Date(wk * ms7d)) {
        var yy = getUTCFullYear();
    }
    
    if(d.getDay()==0){
    	ret = 2 + wk - Math.floor((Date.UTC(yy, 0, 4) + ms3d) / ms7d);
    }else{
    	ret = 1 + wk - Math.floor((Date.UTC(yy, 0, 4) + ms3d) / ms7d);
    }
    return ret;
}
function getDaysOfWeeks(week, year){
	var ms1d = 86400000, ms3d = 3 * ms1d, ms7d = 7 * ms1d;	
	var wk = week + Math.floor((Date.UTC(year, 0, 4) + ms3d) / ms7d) - 1;	
	var sd = new Date(wk * ms7d - ms3d - ms1d);	
	return getWeekArray(sd.getFullYear(), sd.getMonth()+1, sd.getDate());
}
function LastWeekOfYear(Y){ 
	var X1, X2, NW
	with (X1=new Date(Y, 00, 04)) setDate(getDate() - (6+getDay())%7);
	with (X2=new Date(Y, 11, 28)) setDate(getDate() + (7-getDay())%7);
	NW = Math.round((X2-X1)/(7*86400000));
	return  NW;
}
function getAddDays(d, cnt){
    var ms1d = 86400000;
    var ms = Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) + ms1d*cnt;
    return new Date(ms);
}
function getAddTimes(d, h, m){
	var ms1h = 3600000;
	var ms1m = 60000;
	var addms = ms1h*h + ms1m*m;
	var ms = new Date(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes());
	return new Date(ms.valueOf() + addms);
}
function getDayDiff(d1, d2){
    var ms1d = 86400000;
    var ms1 = Date.UTC(d1.getFullYear(), d1.getMonth(), d1.getDate());
    var ms2 = Date.UTC(d2.getFullYear(), d2.getMonth(), d2.getDate());
    return Math.abs((ms2-ms1)/ms1d);
}

// 윤달여부를 체크하여 2월의 날짜수를 설정한다.
function setFebruary(year){	
	if(year % 4 != 0){
		MONTH_DAY_CNT[1] = 28;
	}else if(year % 100 != 0 ){
		MONTH_DAY_CNT[1] = 29;
	}else if(year % 400 != 0){
		MONTH_DAY_CNT[1] = 28;
	}else{
		MONTH_DAY_CNT[1] = 29;
	}
}

function getDaysOfPrevMonth(year, month){
	var ret;
	
	if(month == 1){
		setFebruary(year-1);
		ret = MONTH_DAY_CNT[11];
	}else{	
		setFebruary(year);
		ret = MONTH_DAY_CNT[month - 2];
	}
	return ret;
}

function getDaysOfCurrMonth(year, month){
	var ret;
	
	setFebruary(year);
	ret = MONTH_DAY_CNT[month - 1];
	return ret;
}

function getDaysOfNextMonth(year, month){
	var ret;
	
	if(month == 12){
		setFebruary(year+1);
		ret = MONTH_DAY_CNT[0];
	}else{	
		setFebruary(year);
		ret = MONTH_DAY_CNT[month ];
	}
	return ret;
}

// 입력된 날짜에 해당하는 주의 날짜(배열)을 구한다.
function getWeekArray(year, month, day){
    var CurDate = new Date(year, month-1, day);
    var WeekDay = CurDate.getDay();
    var WeekArray = new Array(7);
	var DaysOfNextMonth;
	var DaysOfCurrMonth;
	var DaysOfPrevMonth;
	var i, iYear, iMonth, iDay;		
	
	iDay = day - WeekDay;
	iMonth = month;
	iYear = year;		
	setFebruary(iYear);
	DaysOfCurrMonth = MONTH_DAY_CNT[iMonth-1];	
	DaysOfNextMonth = getDaysOfNextMonth(iYear, iMonth);
	DaysOfPrevMonth = getDaysOfPrevMonth(iYear, iMonth);
	if(iDay < 1){
		iDay = DaysOfPrevMonth + iDay;
		iMonth = iMonth - 1;
		if(iMonth < 1){
			iMonth = 12;
			iYear = iYear - 1;
		}
	}else if(iDay > DaysOfCurrMonth){
		iDay = iDay - DaysOfCurrMonth;
		iMonth = iMonth + 1;
		if(iMonth == 13){
			iMonth = 1;
			iYear = iYear + 1;
		}
	}	
	setFebruary(iYear);
	DaysOfCurrMonth = MONTH_DAY_CNT[iMonth-1];	
	DaysOfNextMonth = getDaysOfNextMonth(iYear, iMonth);
	DaysOfPrevMonth = getDaysOfPrevMonth(iYear, iMonth);
	
	for(i=0; i<7; i++){
        WeekArray[i] = new Array(3);
        WeekArray[i][0] = iYear;
        WeekArray[i][1] = checkDigit(iMonth);
        WeekArray[i][2] = checkDigit(iDay);
        iDay++;
		if(iDay > DaysOfCurrMonth){
			iDay = iDay - DaysOfCurrMonth;
			iMonth = iMonth + 1;
			DaysOfCurrMonth = DaysOfNextMonth;
			if(iMonth > 12){
				iMonth = 1;
				iYear = iYear + 1;
				setFebruary(iYear);	
				DaysOfCurrMonth = MONTH_DAY_CNT[iMonth-1];
			}
		}
    }    
    return WeekArray;
}

function getWeekCountOfMonth(year, month){
    var CurDate = new Date(year, month-1, 1);
    var WeekDay = CurDate.getDay();
	var DaysOfCurrMonth;
	var r;
	
	setFebruary(year);
	DaysOfCurrMonth = MONTH_DAY_CNT[month-1];
      r = Math.ceil((DaysOfCurrMonth + WeekDay)/7);
	return r;
}
function getWeekCountOf2Months(year, month){
	var currMonthDay,  nMonth, nYear, weekday, r;
	var daysCnt = 0;
	
	if(month==12){
		nYear = year + 1;
		nMonth = 1;
	}else{
		nYear = year;
		nMonth = month+1;
	}
	
	setFebruary(year);
	currMonthDay = new Date(year, month-1, 1);
	weekday = currMonthDay.getDay();
	daysCnt += MONTH_DAY_CNT[month-1] + weekday;
	
	setFebruary(nYear);
	daysCnt += MONTH_DAY_CNT[nMonth-1];
	
      r = Math.ceil(daysCnt/7);
      
	return r;
}
function getWeekCountOf3Months(year, month){
	var prevMonthDay, currMonthDay, nextMonthDay, pMonth, nMonth, pYear, nYear, weekday, r;
	var daysCnt = 0;
	
	if(month==1){
		pYear = year - 1;
		pMonth = 12;
	}else{
		pYear = year;
		pMonth = month-1;
	}
	if(month==12){
		nYear = year + 1;
		nMonth = 1;
	}else{
		nYear = year;
		nMonth = month+1;
	}
	
	setFebruary(pYear);
	prevMonthDay = new Date(pYear, pMonth-1, 1);
	weekday = prevMonthDay.getDay();
	daysCnt += MONTH_DAY_CNT[pMonth-1] + weekday;
	
	setFebruary(year);
	daysCnt += MONTH_DAY_CNT[month-1];
	
	setFebruary(nYear);
	daysCnt += MONTH_DAY_CNT[nMonth-1];
	
      r = Math.ceil(daysCnt/7);
      
	return r;
}
function getMonthArray(year, month, day){ 
    var CurDate = new Date(year, month-1, 1);
    var WeekDay = CurDate.getDay();
	
	setFebruary(year);
	var DaysOfCurrMonth = MONTH_DAY_CNT[month-1];	
	var DaysOfNextMonth = getDaysOfNextMonth(year, month);
	var DaysOfPrevMonth = getDaysOfPrevMonth(year, month); 
	var WeekCountOfMonth = Math.ceil((DaysOfCurrMonth + WeekDay)/7);
	var MonthArray = new Array(WeekCountOfMonth * 7);
	var StartDayOfPrevMonth = DaysOfPrevMonth - WeekDay + 1;
	var i, j, rYear, rMonth;
	
	for(i=0; i<WeekDay; i++){		
		if(month==1){
			rYear  = year-1;
			rMonth = 12;
		}else{
			rYear  = year;
			rMonth = month-1;
		}
		MonthArray[i] = new Array(3);
		MonthArray[i][0] = rYear;
		MonthArray[i][1] = checkDigit(rMonth);
		MonthArray[i][2] = checkDigit(StartDayOfPrevMonth + i);
	}
	
	for(i=0; i<DaysOfCurrMonth; i++){		
		MonthArray[WeekDay+i] = new Array(3);
		MonthArray[WeekDay+i][0] = year;
		MonthArray[WeekDay+i][1] = checkDigit(month);
		MonthArray[WeekDay+i][2] = checkDigit(i + 1);
	}	
	
	for(i=0; i<((WeekCountOfMonth * 7)-(WeekDay+DaysOfCurrMonth)); i++){		
		if(month==12){
			rYear  = year+1;
			rMonth = 1;
		}else{
			rYear  = year;
			rMonth = month+1;
		}
		MonthArray[WeekDay+DaysOfCurrMonth+i] = new Array(3);
		MonthArray[WeekDay+DaysOfCurrMonth+i][0] = rYear;
		MonthArray[WeekDay+DaysOfCurrMonth+i][1] = checkDigit(rMonth);
		MonthArray[WeekDay+DaysOfCurrMonth+i][2] = checkDigit(i + 1);
	}
	return MonthArray;
}
function get2MonthsArray(year, month){ 
	var weekCnt = getWeekCountOf2Months(year, month);
	var MonthArray = new Array(weekCnt * 7);
	var pDays, cDays, nDays, nnDays, pMonth, nMonth, nnMonth, pYear, nYear, nnYear;
	
	if(month==1){
		pYear = year - 1;
		pMonth = 12;
	}else{
		pYear = year;
		pMonth = month-1;
	}
	if(month==12){
		nYear = year + 1;
		nMonth = 1;
	}else{
		nYear = year;
		nMonth = month+1;
	}	
	if(nMonth==12){
		nnYear = nYear + 1;
		nnMonth = 1;
	}else{
		nnYear = nYear;
		nnMonth = nMonth+1;
	}
	
	var firstDate = new Date(year, month-1, 1);
	var weekday = firstDate.getDay();
	
	pDays = getDaysOfPrevMonth(year, month);
	
	setFebruary(year);
	cDays = MONTH_DAY_CNT[month-1];
	
	setFebruary(nYear);
	nDays = MONTH_DAY_CNT[nMonth-1];
	
	nnDays = getDaysOfNextMonth(nYear, nMonth);
	
	var startDay = pDays - weekday + 1;
	
	var idx = 0;
	for(var i=0; i<weekday; i++){	
		MonthArray[idx] = new Array(3);
		MonthArray[idx][0] = pYear;
		MonthArray[idx][1] = checkDigit(pMonth);
		MonthArray[idx][2] = checkDigit(startDay + i);
		idx++;
	}
	
	for(var i=0; i<cDays; i++){		
		MonthArray[idx] = new Array(3);
		MonthArray[idx][0] = year;
		MonthArray[idx][1] = checkDigit(month);
		MonthArray[idx][2] = checkDigit(i + 1);
		idx++;
	}		
	
	for(var i=0; i<nDays; i++){		
		MonthArray[idx] = new Array(3);
		MonthArray[idx][0] = nYear;
		MonthArray[idx][1] = checkDigit(nMonth);
		MonthArray[idx][2] = checkDigit(i + 1);
		idx++;
	}
	
	var endDate = new Date(nYear, nMonth-1, 1);
	var nWeekday = endDate.getDay();	
	var nweekCnt = Math.ceil((nDays + nWeekday)/7);
	for(i=0; i<((nweekCnt * 7)-(nWeekday+nDays)); i++){	
		MonthArray[idx] = new Array(3);
		MonthArray[idx][0] = nnYear;
		MonthArray[idx][1] = checkDigit(nnMonth);
		MonthArray[idx][2] = checkDigit(i + 1);
		idx++;
	}
	return MonthArray;
}
function get3MonthsArray(year, month){ 
	var weekCnt = getWeekCountOf3Months(year, month);
	var MonthArray = new Array(weekCnt * 7);
	var ppDays, pDays, cDays, nDays, nnDays, ppMonth, pMonth, nMonth, nnMonth, pYear,  ppYear, nYear, nnYear;
	
	if(month==1){
		pYear = year - 1;
		pMonth = 12;
	}else{
		pYear = year;
		pMonth = month-1;
	}
	if(pMonth==1){
		ppYear = pYear - 1;
		ppMonth = 12;
	}else{
		ppYear = pYear;
		ppMonth = pMonth-1;
	}	
	if(month==12){
		nYear = year + 1;
		nMonth = 1;
	}else{
		nYear = year;
		nMonth = month+1;
	}	
	if(nMonth==12){
		nnYear = nYear + 1;
		nnMonth = 1;
	}else{
		nnYear = nYear;
		nnMonth = nMonth+1;
	}
	
	var firstDate = new Date(pYear, pMonth-1, 1);
	var weekday = firstDate.getDay();
	
	ppDays = getDaysOfPrevMonth(pYear, pMonth);
	
	setFebruary(pYear);
	pDays = MONTH_DAY_CNT[pMonth-1];
	
	setFebruary(year);
	cDays = MONTH_DAY_CNT[month-1];
	
	setFebruary(nYear);
	nDays = MONTH_DAY_CNT[nMonth-1];
	
	nnDays = getDaysOfNextMonth(nYear, nMonth);
	
	var startDay = ppDays - weekday + 1;
	
	var idx = 0;
	for(var i=0; i<weekday; i++){	
		MonthArray[idx] = new Array(3);
		MonthArray[idx][0] = ppYear;
		MonthArray[idx][1] = checkDigit(ppMonth);
		MonthArray[idx][2] = checkDigit(startDay + i);
		idx++;
	}
	
	for(var i=0; i<pDays; i++){		
		MonthArray[idx] = new Array(3);
		MonthArray[idx][0] = pYear;
		MonthArray[idx][1] = checkDigit(pMonth);
		MonthArray[idx][2] = checkDigit(i + 1);
		idx++;
	}	
	
	for(var i=0; i<cDays; i++){		
		MonthArray[idx] = new Array(3);
		MonthArray[idx][0] = year;
		MonthArray[idx][1] = checkDigit(month);
		MonthArray[idx][2] = checkDigit(i + 1);
		idx++;
	}		
	
	for(var i=0; i<nDays; i++){		
		MonthArray[idx] = new Array(3);
		MonthArray[idx][0] = nYear;
		MonthArray[idx][1] = checkDigit(nMonth);
		MonthArray[idx][2] = checkDigit(i + 1);
		idx++;
	}
	
	var endDate = new Date(nYear, nMonth-1, 1);
	var nWeekday = endDate.getDay();	
	var nweekCnt = Math.ceil((nDays + nWeekday)/7);
	for(i=0; i<((nweekCnt * 7)-(nWeekday+nDays)); i++){	
		MonthArray[idx] = new Array(3);
		MonthArray[idx][0] = nnYear;
		MonthArray[idx][1] = checkDigit(nnMonth);
		MonthArray[idx][2] = checkDigit(i + 1);
		idx++;
	}
	return MonthArray;
}
function getDaysCountInMonth(year, month){ 
    var CurDate = new Date(year, month-1, 1);
    var WeekDay = CurDate.getDay();
	
	setFebruary(year);
	var DaysOfCurrMonth = MONTH_DAY_CNT[month-1];
	var WeekCountOfMonth = Math.ceil((DaysOfCurrMonth + WeekDay)/7);
	var r = WeekCountOfMonth * 7;
	
	return r;
}
function makeKey(str){
	var random;
	var today  = new Date();
	var year   = today.getFullYear();
	var month  = checkDigit(today.getMonth()+1);
	var day    = checkDigit(today.getDate());
	var hour   = checkDigit(today.getHours());
	var minute = checkDigit(today.getMinutes());
	var second = checkDigit(today.getSeconds());
	var strKey = year + month + day + hour + minute + second;
	
	for(var i=strKey.length; i<24; i++){
		random = parseInt((1 + (Math.random() * 600)) % 9);
		strKey += random.toString();
	}
	return str + strKey;
}
function ltrim(para){
    while(para.substring(0,1) == ' ')
        para = para.substring(1, para.length);
    return para;
}
function mtrim(para){
    for ( i = 0; i < para.length;)
        if ( para.substring(i,i+1) == ' ' )
            para = para.substring(0, i) + para.substring(i+1, para.length);
        else
            i++;
    return para;
}

function rtrim(para){
    while(para.substring(para.length-1, para.length) == ' ')
        para = para.substring(0, para.length-1);
    return para;
}
function checkByteLen(inputText,dbMax){
	var text = inputText;
	var max = dbMax;

    if( CheckByte(text) > dbMax){
        return false;
    }else{
        return true;
    }
}

var IEYES = 0;
var menufacture = navigator.appName;
var version = navigator.appVersion;
var brow = navigator.appName;

if((0 < brow.indexOf('Explorer'))
  && (version.indexOf('4') >= 0 || version.indexOf('5') > 0
  || veirsioni.indexOf('6') > 0 || veirsioni.indexOf('7') > 0
  || veirsioni.indexOf('8') > 0 || veirsioni.indexOf('9') > 0))
{
     IEYES = 1;
}
function CheckByte(str){
    var i;
    var strLen;
    var strByte;
    strLen = str.length;

    if(IEYES == 1){
        for(i=0, strByte=0;i<strLen;i++){
            if(str.charAt(i) >= ' ' && str.charAt(i) <= '~' )
                strByte++;
            else
                strByte += 2;
        }
        return strByte;
    }else{
        return strLen;
    }
}
function lrtrim(src){
    var search = 0
    while ( src.charAt(search) == " "){
        search = search + 1
    }
    src = src.substring(search, (src.length))
    search = src.length - 1
    while (src.charAt(search) ==" "){
        search = search - 1
    }
    return src.substring(0, search + 1)
}
function chkHour(startDate,endDate,startHour,endHour,selIndex, checkType){
    var v_FromDate = getYYYYMMDD(startDate.value)+ checkDigit(startHour.value);
    var v_ToDate = getYYYYMMDD(endDate.value)+ checkDigit(endHour.value);

    if(checkType=='S' && selIndex != '0' && selIndex != '23') selIndex = selIndex+1;
    if(checkType=='E' && selIndex != '0' && selIndex != '23') selIndex = selIndex-1;


    // 날짜 선후관계 check
    if(  v_FromDate  > v_ToDate){
        if(checkType=='S'){
            endHour.options[selIndex].selected = true;
            endHour.focus();
        }else if(checkType=='E'){
			startHour.options[selIndex].selected = true;
			startHour.focus();
        }
       return;
    }
}
function chkMin(startDate,endDate,startHour,endHour,startMin,endMin,selIndex, checkType){
    var v_FromDate = getYYYYMMDD(startDate.value)+ checkDigit(startHour.value) + startMin.value;
    var v_ToDate = getYYYYMMDD(endDate.value)+ checkDigit(endHour.value) + endMin.value;
    
    if(checkType=='S' && selIndex != 0 && selIndex != startMin.options.length) selIndex = selIndex+1;
    if(checkType=='E' && selIndex != 0 && selIndex != endMin.options.length) selIndex = selIndex-1;


    // 날짜 선후관계 check    
    if(v_FromDate > v_ToDate){
        if(checkType=='S'){
            //alert('S');
            endMin.options.selectedIndex = selIndex;
            endMin.focus();
        }else if(checkType=='E'){
            startMin.options.selectedIndex = selIndex;
            startMin.focus();
        }
       return;
    }
}


function ufnSetQuickDate(thisForm, dayDiffer) {
		var objFrm = thisForm;
		var objDate = new Date();
		var nowYear		= objDate.getYear();
		var nowMonth	= (objDate.getMonth()+1);
		var nowDay		= objDate.getDate();
		var nowDate		= nowYear + "-" + checkDigit(nowMonth) + "-" + checkDigit(nowDay);		
		
		objFrm.startDate.value = nowDate;
		
		objDate.setDate(objDate.getDate()+dayDiffer);
	
		var quickYear	= objDate.getYear();
		var quickMonth	= (objDate.getMonth()+1);
		var quickDay	= objDate.getDate();
		var quickDate	= quickYear + "-" + checkDigit(quickMonth) + "-" + checkDigit(quickDay);
		
		objFrm.endDate.value = quickDate;
		
		//objFrm.submit();
}

function ufnSetQuickDate2(startDateFormName, endDateFormName, dayDiffer) {

		var objDate = new Date();
		var nowYear		= objDate.getYear();
		var nowMonth	= (objDate.getMonth()+1);
		var nowDay		= objDate.getDate();
		var nowDate		= nowYear + "-" + checkDigit(nowMonth) + "-" + checkDigit(nowDay);		
		
		document.getElementById(startDateFormName).value = nowDate;

		objDate.setDate(objDate.getDate()+dayDiffer);
	
		var quickYear	= objDate.getYear();
		var quickMonth	= (objDate.getMonth()+1);
		var quickDay	= objDate.getDate();
		var quickDate	= quickYear + "-" + checkDigit(quickMonth) + "-" + checkDigit(quickDay);
		
		document.getElementById(endDateFormName).value = quickDate;
}

/**
* 선택된 날짜 초기화
* @param obj1	시작날짜 id
* @param obj2 마지막 날짜 id
* @return
*/

function removeDate(obj1, obj2) {

	if ( ($(obj1)) != null  && (obj1 != "") || (obj1 != undefined) ) {
		$(obj1).value = "";
	}
	if ( ($(obj2) != null)  && (obj2 != "") && (obj2 != undefined) ) {
		$(obj2).value = "";
	}
}
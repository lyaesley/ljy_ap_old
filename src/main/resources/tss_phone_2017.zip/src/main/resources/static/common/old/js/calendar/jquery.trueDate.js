jQuery(document).ready( function() {
	jQuery.fn.trueDate = function(option) {
		this.each(function() {
			var sDate 	= jQuery(this).val().split("-");
			var eDateObj = jQuery(this).next('input:text');
			jQuery(this).attr({'maxlength':'10', 'readonly':'readonly'}).css('width', '70px');
			eDateObj.attr({'maxlength':'10', 'readonly':'readonly'}).css('width', '70px');


			// 시작, 종료 날자 calendar 를 화면에 표시한다.
			jQuery(this).datepicker({
				changeFirstDay: false,
				hideIfNoPrevNext: true,
				onSelect: function(date) {
					var chgDate = date.split("-");
					if( date > eDateObj.val() ){
						eDateObj.val(date);
					}
					eDateObj.datepicker('option', 'minDate', new Date(chgDate[0], chgDate[1] - 1, chgDate[2]));
				}
			});

			eDateObj.datepicker({
				changeFirstDay: false,
				hideIfNoPrevNext: true,
				minDate: new Date(sDate[0], sDate[1] - 1, sDate[2]),
				onSelect: function(date) {
					if (option.fn != undefined) {
						return option.fn.apply();
					}
				}
			});
		});
		return this;
	};
});
package tss.common;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ModelClassHelper {
	
	@Autowired
	SqlSessionTemplate sql;
	
	public String toModelClass(String className, String statement) {
		return toModelClass(className, sql.selectList(statement));
	}
	
//	public String toModelClass(String className, String statement, Object parameter) {
//		sql.selectCursor(statement, parameter);
//	}
	
//	public String toModelClass(String className, String statement, Object parameter) {
//		sql.selectCursor(statement, parameter)
//	}
	
	/**
	 * 메퍼 만들기 귀찮은 사람들을 위해 생성되는 클래스<br>
	 * 사용전 resultType="java.util.LinkedHashMap" 로 설정해 주셔야 순서가 꼬이지 않습니다.
	 * 2017-01-23 박용서 : 작성
	 * @param map
	 * @return
	 */
	public static String toModelClass(String className, Map<String, Object> map) {
		if (map == null) {
			return "결과값이 없기에 모델 클래스를 만들 수 없음 최소 1개이상의 셀릭트 결과가 있어야함.";
		}
		
		Set<String> typeList = new HashSet<>();
		map.values().stream().forEach(type -> typeList.add(type.getClass().getSimpleName()));
		
		StringBuilder sb = 
				new StringBuilder(4096).append("<pre>").append("package tss.dao;").append("<br/>").append("<br/>")
				.append("import lombok.Data;").append("<br/>")
				.append("import lombok.Getter;").append("<br/>")
				.append("import lombok.Setter;").append("<br/>")
				.append("import lombok.ToString;").append("<br/>");
		
		// 타입 import
		typeList.stream().forEach(type -> {
			if (type != null) {
				switch (type) {
					case "Timestamp" : sb.append("import java.util.Date;").append("<br/>"); break;
				}
			}
		});
		
		sb.append("<br/>").append("@Data @Getter @Setter @ToString").append("<br/>")
			.append("public class ").append(className).append(" {").append("<br/>");
		
		map.keySet().stream().forEach(key -> {
			sb.append("\t");
			
			if (key != null) {
				switch (map.get(key).getClass().getSimpleName()) {
					case "Timestamp" : sb.append("Date"); break;
					default : sb.append("String");
				}
			} else {
				sb.append("널값지정바람");
			}
			
			sb.append(' ').append(key.toLowerCase()).append(';').append("\r\n");
		});
			
		sb.append("}").append("<br/>").append("</pre>");
		
		log.info("뭔가 만듬....");
				
		return sb.toString();
	}
	
	/**
	 * 메퍼 만들기 귀찮은 사람들을 위해 생성되는 클래스<br>
	 * 2017-01-23 박용서 : 작성
	 * @param map
	 * @return
	 */
	public static String toModelClass(String className, List<Map<String, Object>> list) {
		return toModelClass(className, list.size() > 0 ? list.get(0) : null);
	}
}

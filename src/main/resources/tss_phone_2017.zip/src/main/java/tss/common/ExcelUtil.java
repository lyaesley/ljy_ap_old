package tss.common;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

/**
 * 2017-01-24 박용서 : 작성
 */
final public class ExcelUtil {
	
	public static void writeResponse(HttpServletResponse response, String filenameWithoutExt, List<Map<String, Object>> list, LinkedHashMap<String, String> header) throws IOException {
		response.setContentType("contentType=application/vnd.ms-excel;charset=UTF-8");
    	response.setHeader("Content-disposition", "attachment; filename="+filenameWithoutExt+".xlsx");
    	writeOutputStream(response.getOutputStream(), list, header);
	}
	
	public static void writeOutputStream(OutputStream out, List<Map<String, Object>> list, LinkedHashMap<String, String> header) throws IOException {
		SXSSFWorkbook wb = new SXSSFWorkbook(100);
		SXSSFSheet sheet = wb.createSheet();
		SXSSFRow row;
		SXSSFCell cell;
		int rownum = 0;
		int cellnum = 0;
		
		if (list.size() > 0) {
			List<String> column = new ArrayList<>();
			
			if (header != null) {
				row = sheet.createRow(rownum++);
				for (String key : header.keySet()) {
					column.add(key);
					cell = row.createCell(cellnum++);
					cell.setCellValue(header.get(key));
				}
			} else {
				list.get(0).keySet().stream().forEach(key -> {
					column.add(key);
				});
			}
			
			for (Map<String, Object> map : list) {
				cellnum = 0;
				row = sheet.createRow(rownum++);
				for (String key : header.keySet()) {
					cell = row.createCell(cellnum++);
					Object val = map.get(key);
					cell.setCellValue(val != null ? val.toString() : null);
				}
			}
		}
		
        wb.write(out);
        out.close();
        wb.dispose();
        wb.close();
	}
}

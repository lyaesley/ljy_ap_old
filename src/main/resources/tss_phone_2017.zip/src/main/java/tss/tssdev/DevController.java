package tss.tssdev;

import org.springframework.stereotype.Controller;

@Controller
public class DevController {

}

package tss.dao;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import tss.model.TestCustInfo;

@Component
public class FirstDao {
	
	@Autowired
	SqlSessionTemplate sql;
	
	public List<Map<String, Object>> cust_list() {
		return sql.selectList("first.cust_info");
	}
	
	public List<TestCustInfo> cust_info_class() {
		return sql.selectList("first.cust_info_class");
	}
	
}

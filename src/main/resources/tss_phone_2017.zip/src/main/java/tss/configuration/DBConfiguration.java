package tss.configuration;

import java.io.IOException;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
@EnableTransactionManagement
public class DBConfiguration {
	
	@Autowired
	@Qualifier("tssDataSource")
	DataSource tssDataSource;
	
	@Primary
	@Configuration
	@ConfigurationProperties(prefix = "db.tss")
	static class TssDataSource extends HikariConfig {
		@Bean(name = "tssDataSource")
		DataSource tssDataSource() {
			return new HikariDataSource(this);
		}
	}
	
	@Primary
	@Bean(name = "tssSqlSessionFactoryBean")
	public SqlSessionFactoryBean tssSessionFactoryBean(ApplicationContext applicationContext) throws IOException {
		
		SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
		factoryBean.setDataSource(tssDataSource);
		//factoryBean.setConfigLocation(applicationContext.getResource("classpath:META-INF/mybatis/configuration.xml"));
		factoryBean.setMapperLocations(applicationContext.getResources("classpath:mybatis/tss/**.xml"));
		
		return factoryBean;
	}
	
	@Primary
	@Bean(name = "tssSqlSessionTemplate")
    public SqlSessionTemplate tssSqlSessionTemplate(SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }
	
	
	
	
	
//	@Bean(name = "mailDataSource")
//	@ConfigurationProperties(prefix = "db.mail")
//	public DataSource mailDataSource() throws IOException {
//		return DataSourceBuilder.create().build();
//	}
// 
//	@Bean(name = "mysqlFactoryBean")
//	public LocalContainerEntityManagerFactoryBean getFactoryBean(EntityManagerFactoryBuilder builder) throws IOException
//	{
//		return builder.dataSource(getDataSource()).packages("com.web.domain.mysql").build();
//	}
// 
//	@Bean(name = "mysqlTransactionManager")
//	PlatformTransactionManager getTransactionManager(EntityManagerFactoryBuilder builder) throws IOException
//	{
//		return new JpaTransactionManager(getFactoryBean(builder).getObject());
//	}
}

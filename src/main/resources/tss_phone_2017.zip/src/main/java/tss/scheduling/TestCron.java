package tss.scheduling;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;


@Component
@Slf4j
public class TestCron {
	
	@Scheduled(cron="0 0/5 * * * ?")
	public void cron01() {
		log.info("5분이 지났다!!");
	}
}

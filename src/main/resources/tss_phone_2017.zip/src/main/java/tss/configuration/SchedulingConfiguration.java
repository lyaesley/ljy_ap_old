//package tss.configuration;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.springframework.context.annotation.Configuration;
//import org.springframework.scheduling.annotation.EnableScheduling;
//import org.springframework.scheduling.annotation.SchedulingConfigurer;
//import org.springframework.scheduling.config.CronTask;
//import org.springframework.scheduling.config.ScheduledTaskRegistrar;
//
//import com.ts.hardcode.ServerCheck;
//
//import lombok.extern.log4j.Log4j;
//
//@Configuration
//@EnableScheduling
//@Log4j
//class SchedulingConfiguration implements SchedulingConfigurer
//{
//	/** 스케줄 수동설정. [개발서버] */
//	List<CronTask> manual_dev(List<CronTask> cronTasks) {
//		log.info("[개발] 개발/로컬 서버임으로 모든 스케줄을 정지시키고 수동설정합니다.");
//		
//		// 수동 설정할 크론정보
//		// cronTasks.add(new CronTask(() -> tSchedule.execute(), "0/5 * * * * ?")); 자바 8
////			cronTasks.add(new CronTask(new Runnable() { @Override public void run() 
////			{
////					실행할 크론 / 아래는 시간
////			}}, "0/5 * * * * ?"));
//		
//		return cronTasks;
//	}
//	
//	/** 스케줄 수동설정. [스테이징] */
//	List<CronTask> manual_stg(List<CronTask> cronTasks) {
//		log.info("[스테이징] 스테이징 서버임으로 모든 스케줄을 정지시키고 수동설정합니다.");
//		
//		// 수동 설정할 크론정보
//		// cronTasks.add(new CronTask(() -> tSchedule.execute(), "0/5 * * * * ?")); 자바 8
////			cronTasks.add(new CronTask(new Runnable() { @Override public void run() 
////			{
////					실행할 크론 / 아래는 시간
////			}}, "0/5 * * * * ?"));
//		
//		return cronTasks;
//	}
//	
//	// 2017-01-05 박용서 : 하기 코드는 절대 건들지 맙시다.!!
//	// 상용 ADMIN WAS 01 이 아닌경우 함수반환
//	@Override
//	public void configureTasks(ScheduledTaskRegistrar taskRegistrar)
//	{
//		// 상용
//		if (ServerCheck.isRealServer()) {
//			// AdminWas01 서버가 아닌 경우
//			if (!ServerCheck.isAdminWas01())
//			{
//				log.info("[상용] AdminWas01 아니기에 모든 스케줄을 정지 시킵니다.");
//				taskRegistrar.setCronTasksList(new ArrayList<CronTask>());
//			}
//		} 
//		// 스테이징
//		else if (ServerCheck.isStgServer()) {
//			taskRegistrar.setCronTasksList(manual_stg(new ArrayList<CronTask>()));
//		}
//		// 개발 / 로컬
//		else if (ServerCheck.isDevServer()) {
//			taskRegistrar.setCronTasksList(manual_dev(new ArrayList<CronTask>()));
//		}
//		
//	}
//}
package tss.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.extern.slf4j.Slf4j;
import tss.common.ExcelUtil;
import tss.common.ModelClassHelper;
import tss.dao.FirstDao;
import tss.model.TestCustInfo;

@Controller
@Slf4j
class FirstController {
	
	@Autowired
	FirstDao firstdao;
	
	@Autowired
	ModelClassHelper modelClassHelper;
	
	@GetMapping("/first")
	@ResponseBody
	String first() {
		log.info("안녕이라는 로그를 남겨보았다.");
		return "안녕!";
	}
	
	@GetMapping("/first-cust")
	@ResponseBody
	List<Map<String, Object>> firstCust() {
		log.info("ㄴㅁㅇㄹ보았다.");
		return firstdao.cust_list();
	}
	
	@GetMapping("/first-cust2")
	@ResponseBody
	List<String> firstCust2() {
		log.info("안ㅁㄴㅇㄹ 로그를 남겨보았다.");
		
		List<String> list = new ArrayList<>();
		firstdao.cust_list().stream().forEach(e -> list.add(e.get("SVC_NUM").toString()));
		//firstdao.cust_list().stream().forEach(System.out::println);
		
		return list;
	}
	
	@GetMapping("/cust-excel")
	@ResponseBody
	void custExcel(HttpServletResponse res) throws IOException {
		List<Map<String, Object>> list = firstdao.cust_list();
		
		LinkedHashMap<String, String> header = new LinkedHashMap<>();
		header.put("SVC_NUM", "전화번호");
		header.put("CUST_NM", "고객명");
		
		ExcelUtil.writeResponse(res, "excel", list, header);
	}
	
	@GetMapping("/first-cust-class")
	@ResponseBody
	List<TestCustInfo> cust_info_class() {
		
		TestCustInfo a;
		
		
		return firstdao.cust_info_class();
	}
	
	@GetMapping("/first-test")
	@ResponseBody
	String cust_test() {
		return modelClassHelper.toModelClass("AbcDef", "first.cust_info");
	}
}

package tss.model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import java.util.Date;

// 일부러 user_pw를 제외함

@Data @Getter @Setter @ToString
public class PhUser {
	
	// 기본 테이블 정보
	String user_typ;
	String store_id;
	String store_nm;
	String user_nm;
	String user_id;
	String use_yn;
	String regr;
	String updr;
	Date reg_dt;
	Date upd_dt;
	String store_typ;
	String affiliation;
	String user_type;
	Date account_enddate;
	String login_cnt;
}
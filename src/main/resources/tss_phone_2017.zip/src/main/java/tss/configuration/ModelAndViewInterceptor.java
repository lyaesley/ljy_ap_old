package tss.configuration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import tss.service.UserService;

@Component
@PropertySource("classpath:application.properties")
public class ModelAndViewInterceptor extends HandlerInterceptorAdapter {

	@Autowired(required=true)
	UserService userService;
	
	@Value("${common.path.revision}")
	String commonPathRevision;
	
	void baseHead(ModelAndView mav) {
		mav.addObject("_res_jquery", "/webjars/jquery/1.12.4/jquery.min.js");
		mav.addObject("_res_jquery_ui", "/webjars/jquery-ui/1.12.1/jquery-ui.min.js");
		mav.addObject("_res_jquery_ui_css", "/webjars/jquery-ui/1.12.1/jquery-ui.theme.min.css");
		mav.addObject("_res_jquery_ui_structure_css", "/webjars/jquery-ui/1.12.1/jquery-ui.structure.min.css");
		mav.addObject("_res_jquery_ui_theme_css", "/webjars/jquery-ui/1.12.1/jquery-ui.theme.min.css");
		mav.addObject("_common_path", "/common/"+commonPathRevision);
	}

	void baseUser(ModelAndView mav) {
		System.out.println(userService.toString());
		mav.addObject("user", userService);
	}
	
	void baseVars(ModelAndView mav) {
		
	}
	
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		
		if (modelAndView != null) {
			baseHead(modelAndView);
			baseUser(modelAndView);
			baseVars(modelAndView);
		}
	}
}

package tss.service;

import java.io.Serializable;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;
import tss.model.PhUser;

@Component
@Scope(value="session", proxyMode = ScopedProxyMode.TARGET_CLASS)
@Getter @Setter
public class UserService extends PhUser implements Serializable {
	/** 시리얼 라이즈 키 */
	private static final long serialVersionUID = 1L;
	
	@Override
	public String toString() {
		return super.toString();
	}
	
	public static boolean isLogin() {
		return false;
	}
}

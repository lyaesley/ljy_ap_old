package tss.service;

import java.io.Serializable;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Component()
@Scope("session")
@Data @Getter @Setter @ToString
public class UserService implements Serializable {
	private static final long serialVersionUID = 1L;
	
	
	
	public static boolean isLogin() {
		return false;
	}
}
